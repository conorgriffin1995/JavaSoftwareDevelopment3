package example2phones;

import java.util.ArrayList;

public class FootballGame
{
	private String homeTeam, visitingTeam;
	private ArrayList<IFootball> audience;

	public FootballGame(String homeTeam, String visitingTeam)
	{
		this.homeTeam = homeTeam;
		this.visitingTeam = visitingTeam;
		audience = new ArrayList<>();
	}

	public void addFootballListener(IFootball f)
	{
		//add the listener to the Vector
		audience.add(f);
		//tell them who is playing
		f.setHomeTeam(homeTeam);
		f.setVisitingTeam(visitingTeam);
	}

	public void notifyHomeTeamScored(int points)
	{
		//notify the audience that the home team scored              
		for(int i = 0; i < audience.size(); i++)
		{
			//IFootball current = (IFootball) audience.get(i);                      
			(audience.get(i)).homeTeamScored(points);
		}
	}

	public void notifyVisitingTeamScored(int points)
	{
		//notify the audience that the visiting team scored
		for(int i = 0; i < audience.size(); i++)
		{
			audience.get(i).visitingTeamScored(points);
		}

	}

	public void notifyQuarterEnded(int quarter)
	{
		//notify the audience which quarter has just ended
		for(int i = 0; i < audience.size(); i++)
		{
			audience.get(i).endOfQuarter(quarter);
		}
	}
}