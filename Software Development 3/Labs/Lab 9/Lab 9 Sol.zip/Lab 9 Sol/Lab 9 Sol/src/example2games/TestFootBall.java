package example2games;

public class TestFootBall
{
	public static void main(String [] args)
	{
		System.out.println("Instantiating a new FootballGame");
                System.out.println("Welcome to the International Rules");
		FootballGame game1 = new FootballGame("Ireland", "Australia");

		System.out.println("Instantiating a listener");
		MobilePhone scoreBoardJohn = new MobilePhone("John");           

		System.out.println("Registering a listener to the game");
		game1.addFootballListener(scoreBoardJohn);
                

		System.out.println("Simulating a game...");
		game1.notifyHomeTeamScored(7);
		game1.quarterEnded(1);

		game1.notifyVisitingTeamScored(3);
		game1.notifyVisitingTeamScored(7);
		game1.quarterEnded(2);

		game1.quarterEnded(3);

		game1.notifyHomeTeamScored(3);
		game1.notifyHomeTeamScored(7);
		game1.quarterEnded(4);
                
                // -----------------------------------------------------------------------//
                System.out.println("Instantiating a new FootballGame");
                System.out.println("Welcome to the International Rules");
		FootballGame game2 = new FootballGame("Ireland", "New Zealand");

		System.out.println("Instantiating a listener");
                MobilePhone scoreBoardPaul = new MobilePhone("Paul");

		System.out.println("Registering a listener to the game");
                game2.addFootballListener(scoreBoardPaul);
                System.out.println("Simulating a game...");
		game2.notifyHomeTeamScored(1);
		game2.quarterEnded(1);

		game2.notifyVisitingTeamScored(3);
		game2.notifyVisitingTeamScored(1);
		game2.quarterEnded(2);

		game2.quarterEnded(3);

		game2.notifyHomeTeamScored(3);
		game2.notifyHomeTeamScored(1);
		game2.quarterEnded(4);
	}
}