package mytest;

public class TestFootBall
{
	public static void main(String [] args)
	{
		System.out.println("Instantiating a new Football Game");
                System.out.println("Welcome to the International Rules");
		FootballGame game1 = new FootballGame("Ireland", "Australia");

		System.out.println("Instantiating 1st listener");
		MobilePhone scoreBoardJohn = new MobilePhone("John");
               // System.out.println("Instantiating 2nd listener");
               // MobilePhone scoreBoardPaul = new MobilePhone("Paul");    

		System.out.println("Registering 1st listener to the game");
		game1.addFootballListener(scoreBoardJohn);
               // System.out.println("Registering 2nd listener to the game");
               // game1.addFootballListener(scoreBoardPaul);
                

		System.out.println("Simulating a game...");
		game1.notifyHomeTeamScored(7);
		game1.notifyQuarterEnded(1);

		game1.notifyVisitingTeamScored(3);
		game1.notifyVisitingTeamScored(7);
		game1.notifyQuarterEnded(2);

		game1.notifyQuarterEnded(3);

		game1.notifyHomeTeamScored(3);
		game1.notifyHomeTeamScored(7);
		game1.notifyQuarterEnded(4);
                
                
	}
}