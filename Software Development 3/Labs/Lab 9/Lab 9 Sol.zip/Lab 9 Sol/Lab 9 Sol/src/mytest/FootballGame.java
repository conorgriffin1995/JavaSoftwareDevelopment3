/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mytest;

import java.util.ArrayList;

/**
 *
 * @author pmage_000
 */
public class FootballGame {
    private String homeTeam;
    private String visitorTeam;
    private ArrayList<IFootball> audience;
    
    public FootballGame(String h, String v)
    {
        this.homeTeam = h;
        this.visitorTeam = v;
        audience = new ArrayList<>();
    }
    
    public void addFootballListener(IFootball f)
    {
        audience.add(f);
        f.setHomeTeam(homeTeam);
        f.setVisitingTeam(visitorTeam);        
    }
    
    public void notifyHomeTeamScored(int points)
    {
        for(int i=0;i<audience.size();i++)
        {
            audience.get(i).homeTeamScored(points);
        }
    }
     public void notifyVisitingTeamScored(int points)
    {
        for(int i=0;i<audience.size();i++)
        {
            audience.get(i).visitingTeamScored(points);
        }
    }
      public void notifyQuarterEnded(int qtr)
    {
        for(int i=0;i<audience.size();i++)
        {
            audience.get(i).endOfQuarter(qtr);
        }
    }
}
