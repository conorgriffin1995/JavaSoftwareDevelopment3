/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mytest;

/**
 *
 * @author pmage_000
 */
public class MobilePhone implements IFootball {

    private String owner;
    private String homeTeam;
    private String visitorTeam;

    private int homeScore, visitorScore;
    private int currentQuarter;

    public MobilePhone(String owner) {
        this.owner = owner;
        currentQuarter = 1;
    }

    @Override
    public void setHomeTeam(String name) {
        this.homeTeam = name;
    }

    @Override
    public void setVisitingTeam(String name) {
        this.visitorTeam = name;
    }

    public void displayQuarter() {
        if (currentQuarter > 0) {
            System.out.println("Hi " + owner + " Game is in quarter " + currentQuarter);
        } else {
            System.out.println("Hi " + owner + " Final Score");
        }
    }

    public void updateScore() {
        System.out.println("*************************************");
        System.out.println(homeTeam + " " + homeScore);
        System.out.println(visitorTeam + " " + visitorScore);
        displayQuarter();
        System.out.println("*************************************");

    }

    @Override
    public void endOfQuarter(int quarter) {
        if ((quarter >=1) && (quarter <= 3)) {
            currentQuarter++;

        } else {
            currentQuarter = -1;
        }
        System.out.println("Hi " + owner + " Quarter " + quarter + " has just ended");
        updateScore();
    }

    @Override
    public void homeTeamScored(int points) {
        System.out.println("Hi " + owner + " The home team has just scored " + points + " points");
        homeScore += points;
        updateScore();
    }

    @Override
    public void visitingTeamScored(int points) {
        System.out.println("Hi " + owner +  " The visitor team has just scored " + points + " points");
        visitorScore += points;
        updateScore();
    }



    
    
}
