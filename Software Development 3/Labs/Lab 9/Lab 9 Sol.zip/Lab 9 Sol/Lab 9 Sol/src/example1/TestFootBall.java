package example1;

public class TestFootBall
{
	public static void main(String [] args)
	{
		System.out.println("Instantiating a new Football Game");
                System.out.println("Welcome to the International Rules");
		FootballGame game = new FootballGame("Ireland", "Australia");

		System.out.println("Instantiating a listener");
		MobilePhone scoreBoard = new MobilePhone("John");

		System.out.println("Registering a listener to the game");
		game.addFootballListener(scoreBoard);

		System.out.println("Simulating a game...");
		game.notifyHomeTeamScored(7);
		game.notifyQuarterEnded(1);

		game.notifyVisitingTeamScored(3);
		game.notifyVisitingTeamScored(7);
		game.notifyQuarterEnded(2);

		game.notifyQuarterEnded(3);

		game.notifyHomeTeamScored(3);
		game.notifyHomeTeamScored(7);
		game.notifyQuarterEnded(4);
	}
}