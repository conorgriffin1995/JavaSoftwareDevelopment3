package example1;

public class MobilePhone implements IFootball
{
	private String owner;
        private String home, visitors;
	private int homePoints, visitorPoints;
	private int currentQuarter;

	public MobilePhone(String owner)
	{
            this.owner = owner;
            currentQuarter = 1;
	}
        @Override
	public void setHomeTeam(String name)
	{
		home = name;
	}

        @Override
	public void setVisitingTeam(String name)
	{
		visitors = name;
	}

        public void displayQuarter()
	{
		if(currentQuarter > 0)
		{
			System.out.println("Hi " +owner+" Game is in quarter " + currentQuarter);
		}
		else
		{
			System.out.println("Hi " +owner+" Final score");
                        homePoints=0;
                        visitorPoints=0;
		}
	}
        public void updateScore()
	{
		System.out.println("*************************************");
		System.out.println(home + ": " + homePoints);
		System.out.println(visitors + ": " + visitorPoints);
		displayQuarter();
		System.out.println("*************************************");
	}
        @Override
	public void endOfQuarter(int quarter)
	{

		if(quarter >= 1 && quarter <= 3)
		{
			currentQuarter++;
		}
		else
		{
			currentQuarter = -1;	//game is over
		}
		System.out.println("Hi " +owner+" Quarter " + quarter + " just ended.");
		updateScore();
	}
	

	

        @Override
	public void homeTeamScored(int points)
	{
		System.out.println("Hi " +owner+" The home team just scored " + points);
		homePoints += points;
		updateScore();
	}

        @Override
	public void visitingTeamScored(int points)
	{
		System.out.println("Hi " +owner+" The visiting team just scored " + points);
		visitorPoints += points;
		updateScore();
	}

        

        
}