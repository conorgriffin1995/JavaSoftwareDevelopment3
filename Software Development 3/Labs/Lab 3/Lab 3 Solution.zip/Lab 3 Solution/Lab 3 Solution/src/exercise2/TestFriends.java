/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise2;

import java.util.Scanner;

/**
 *
 * @author pmage_000
 */
public class TestFriends {

    public static void main(String args[]) {

        Scanner in = new Scanner(System.in);

        String name, no, newnum;
        int numFriends;
        boolean found = false;

        System.out.println("Please enter the number of friends in your phone book");
        numFriends = in.nextInt();
        in.nextLine();

        Friend phone[] = new Friend[numFriends];

        for (int i = 0; i < phone.length; i++) {
            System.out.println("Please enter name");
            name = in.nextLine();

            System.out.println("Please enter number");
            no = in.nextLine();

            phone[i] = new Friend(name, no);
        }
        System.out.println("Phone Book Details");
        for (int i = 0; i < phone.length; i++) {
            System.out.println(phone[i]);
        }

        while (found == false) {
            System.out.println("Please enter the name of the person whose number you wish to update:");
            name = in.nextLine();

            for (int i = 0; i < phone.length; i++) {
                if (name.equals(phone[i].getName())) {

                    System.out.println("Enter the new number for " + name);
                    newnum = in.nextLine();
                    phone[i].setNumber(newnum);
                    found = true;
                }
            }
            if (found == false) {
                System.out.println("Name not in book");
            }
        }
        System.out.println("Phone Book Details");
        for (int i = 0; i < phone.length; i++) {
            System.out.println(phone[i]);
        }
    }

}
