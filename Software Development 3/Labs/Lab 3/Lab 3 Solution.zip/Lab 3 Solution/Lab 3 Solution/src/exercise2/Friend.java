/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise2;

/**
 *
 * @author pmage_000
 */
public class Friend {

    private String name;
    private String no;

    public Friend() {
        this.name = "";
        this.no = "";
    }

    public Friend(String n, String num) {
        this.name = n;
        this.no = num;
    }

    public String getName() {
        return name;

    }

    public String getNumber() {
        return no;

    }

    public void setNumber(String num) {
        no = num;
    }

    public void setName(String newname) {
        name = newname;
    }

    public String toString() {
        return "Name " + name + "\nNumber " + no;
    }

}
