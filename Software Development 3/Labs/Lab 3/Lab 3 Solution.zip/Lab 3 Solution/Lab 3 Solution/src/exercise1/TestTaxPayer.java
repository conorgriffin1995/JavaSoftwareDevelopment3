/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise1;

import java.util.Scanner;

/**
 *
 * @author pmage_000
 */
public class TestTaxPayer {
    public static void main(String args[])
	{
        Scanner in = new Scanner(System.in);

        int[] rsiNums;
        double[] salary;
        int numPayers;
        TaxPayer[] list;

        System.out.println("Please enter the number of taxpayers");
        numPayers = in.nextInt();
        in.nextLine();

        rsiNums = new int[numPayers];
        salary = new double[numPayers];
        list = new TaxPayer[numPayers];

        for (int i = 0; i< numPayers; i++) {
            System.out.println("Please enter the rsi number for tax payer:" + (i+1));
            rsiNums[i] = in.nextInt();
            System.out.println("Please enter the salary for tax payer:" + (i+1));
            salary[i] = in.nextDouble();
            list[i] = new TaxPayer(rsiNums[i], salary[i]);
        }

		for (int i = 0; i< list.length; i++)
		{
			System.out.println("RSI no = " + list[i].getRSI());
			System.out.printf("Gross salary = €%,.2f%n",list[i].getGross());
		}
	}

    
}
