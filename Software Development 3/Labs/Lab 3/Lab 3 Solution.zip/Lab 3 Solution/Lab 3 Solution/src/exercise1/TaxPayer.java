/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise1;

/**
 *
 * @author pmage_000
 */
public class TaxPayer {
    private int rsi;
	private double gross;
	
	public TaxPayer()
    {
        this.rsi = 0;
        this.gross = 0;
    }

    public TaxPayer(int r, double g)
	{
		rsi = r;
		gross = g;
	}
	
	public int getRSI()
	{
		return rsi;
	}
	
	public double getGross()
	{
		return gross;
	}

    public void setRsi(int rsi) {this.rsi = rsi;}

    public void setGross(double gross) { this.gross = gross;}

}
