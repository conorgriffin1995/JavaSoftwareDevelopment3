package lab.pkg8.sol;

public class Square extends TwoDShape
 {
	// three-argument constructor
	public Square( int x, int y, int side )
		{
			super( x, y, side, side );
		} // end three-argument Square constructor

	// overridden methods
	public String getName()
		{
			return "Square";
		} // end method getName

	public int getArea()
		{
			return getSide() * getSide();
		} // end method getArea

	// get method
	public int getSide()
		{
			return getd1();
		} // end method getSide

	public String toString()
		{
			return super.toString()+ " side:"+ getSide();
		} // end method toString
 } // end class Square
