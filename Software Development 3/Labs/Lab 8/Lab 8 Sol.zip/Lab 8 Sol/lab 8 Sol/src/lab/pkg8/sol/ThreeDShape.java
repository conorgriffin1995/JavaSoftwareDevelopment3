package lab.pkg8.sol;

public abstract class ThreeDShape extends Shape
 {
	private int d1;
	private int d2;
	private int d3;

 
 public ThreeDShape(int x, int y, int d1, int d2, int d3 )
 	{
	 	super( x, y );
	 	this.d1 = d1;
	 	this.d2 = d2;
	 	this.d3 = d3;
 	} 

 // get methods
 public int getLength()
 		{
	 	return d1;
 		} 

 public int getWidth()
 		{
	 		return d2;
 		} 

 public int getHeight()
 	{
	 	return d3;
 	} // end method getDimension3

 // abstract methods
 public abstract int getArea();
 public abstract int getVolume();
 } // end class ThreeDimensionalShape
