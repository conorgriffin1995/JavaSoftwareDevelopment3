package lab.pkg8.sol;

public abstract class Shape
 {
	private int x; // x coordinate
	private int y; // y coordinate
	private static int total = 0;

	// two-argument constructor
	public Shape( int x, int y )
	{
		this.x = x;
		this.y = y;
		total++;
	} // end two-argument Shape constructor

	// get x coordinate
	public int getX()
	{
		return x;
	} // end method getX

	// get y coordinate
	public int getY()
	{
		return y;
	} // end method getY
	
	// get y coordinate
	public static int getTotal()
	{
		return total;
	} // end method getY
	// return String representation of Shape object
	public String toString()
	{
		return "(" +x+ ","+y+")";
	}

	// abstract methods
	public abstract String getName();
 } // end class Shape


