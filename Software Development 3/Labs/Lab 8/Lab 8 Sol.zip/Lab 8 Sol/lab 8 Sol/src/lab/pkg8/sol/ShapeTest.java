package lab.pkg8.sol;

import java.text.DecimalFormat;

public class ShapeTest
  {
  // create Shape objects and display their information
  public static void main( String args[] )
   {
	  Shape shapes[] = new Shape[ 4 ];
	  shapes[0] = new Circle(22,88,4);
	  shapes[1] = new Square(71,96,10);
	  shapes[2] = new Sphere(8,89,2);
	  shapes[3] = new Cube(79,61,8);
          
          final double COVERAGE = 70;
	  double amount = 0.0;
	  Paint paint = new Paint(COVERAGE);
	  double max = 0.0;
	  double min = Integer.MAX_VALUE;
	  double totalPaint = 0.0;
	  String maxName="", minName="";
          DecimalFormat df = new DecimalFormat("#.##");

	  // call method print on all shapes
	  for ( int i=0;i<shapes.length;i++)
	  	{
		  System.out.println(shapes[i].getName() + shapes[i]);

		  	if (shapes[i] instanceof TwoDShape )
		  		{
		  			TwoDShape twoDShape =(TwoDShape) shapes[i];
		  			System.out.println( "Area of " +shapes[i].getName()+" is: "+twoDShape.getArea());
		  			System.out.println();
		  		} // end if

		  	if (shapes[i] instanceof ThreeDShape )
		  		{
		  			ThreeDShape threeDShape = ( ThreeDShape ) shapes[i];
		  			System.out.println("Area of "+threeDShape.getName()+" is: "+threeDShape.getArea() );
		  			System.out.printf( "Volume of "+threeDShape.getName()+" is: "+threeDShape.getVolume());
		  			System.out.println();
		  			System.out.println();
		  		} // end if	
                        
                        amount = paint.calcAmount(shapes[i]);
		  	System.out.println ("Amount of paint required for " + shapes[i].getName() +" is " +df.format(amount) +" litres");
		  	
		  	totalPaint = totalPaint + amount;
		  	if (amount > max)
		  		{
		  			max = amount;
		  			maxName = shapes[i].getName();
		  		}   
		  	if (amount < min)
		  		{
		  			min = amount;
		  			minName = shapes[i].getName();
		  		}
		  
		  	
		  	
		  	System.out.println();
	  	} // end for
	    
	  	System.out.println ("The total amount of paint required is: "+df.format(totalPaint) + " litres");
	  	System.out.println ("The name of the shape that requires the most paint is: "+maxName);
	  	System.out.println ("The name of the shape that requires the least paint is: "+minName);
	        System.out.println ("The number of shapes created is:"+Shape.getTotal());

     } // end main
}// end class ShapeTest
