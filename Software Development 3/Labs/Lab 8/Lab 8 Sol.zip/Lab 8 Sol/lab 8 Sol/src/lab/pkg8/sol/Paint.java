package lab.pkg8.sol;

public class Paint {
	private double coverage; //number of square feet per litre
	//-----------------------------------------
	// Constructor: Sets up the paint object.
	//-----------------------------------------
	public Paint(double c)
	{
	coverage = c;
	}
	
	//---------------------------------------------------
	// Returns the amount of paint (number of litres)
	// needed to paint the shape given as the parameter.
	//---------------------------------------------------
	public double calcAmount(Shape s)
	{
		double amount = 0.0;
		
		if (s instanceof TwoDShape )
		{
			TwoDShape twoDShape =(TwoDShape) s;		
			amount = (twoDShape.getArea()/coverage);
		}
		else 
  		{
  			ThreeDShape threeDShape = ( ThreeDShape ) s;
  			amount = (threeDShape.getArea()/coverage);
  		}
		  
		  return amount;
	}

}
