/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labonesol;

/**
 *
 * @author pmage_000
 */
public class TestEmployee {
    public static void main(String args[])
    {
        Engineer e = new Engineer(101,"Jane Smith","2378675D",120345.27);
        Admin a = new Admin(304,"Bill Munroe","0978654V",75002.34);
        Manager m = new Manager(207,"Barbara Johnson","8765667Y",109501.36,"European Marketing");
        Director d = new Director(122,"Susan Wheeler","9876547B",120567.36,"Global Marketing",1000000.0);
        
        e.print();
        System.out.println("-----------------");
        a.print();
        System.out.println("-----------------");
        m.print();
        System.out.println("-----------------");
        d.print();
        
        
        m.raiseSalary(10000);
        m.setName("Barbara Johnson-Smyth");
        System.out.println("-----------------");
        m.print();
        
    }
    
}
