/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labonesol;

/**
 *
 * @author pmage_000
 */
public class Engineer extends Employee{
    public Engineer(int id, String n, String ssn, double sal)
    {
        super(id,n,ssn,sal);
    }
}
