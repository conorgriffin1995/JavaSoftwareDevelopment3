/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labonesol;

/**
 *
 * @author pmage_000
 */
public class Manager extends Employee{
    private String deptName;
    
    public Manager(int id, String n, String ssn, double sal,String dName)
    {
        super(id,n,ssn,sal);
        deptName = dName;
    }
    
    public String getDeptName()
    {
        return deptName;
    }
    public void print()
    {
        super.print();
        System.out.println("Department:      " + getDeptName());
    }
}
