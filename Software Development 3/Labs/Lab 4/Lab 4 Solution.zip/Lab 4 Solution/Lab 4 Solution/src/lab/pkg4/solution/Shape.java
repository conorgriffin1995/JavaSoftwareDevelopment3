package lab.pkg4.solution;

public abstract class Shape {
	// Instance variable
	   private String color;
	   protected double area;
           private String type;
	   
	   // Constructor
	   public Shape (String type,String color) {
              this.type=type;
	      this.color = color;
	      this.area = 0.0;
	   }
	   
	   public void print() {
               System.out.println("Typer of Shape is: " + type);
	      System.out.println("Colour of Shape is: " + color);
	   }
	   
	   // All shapes must have a method called calcArea()
	   public abstract void calcArea();
}


