package lab.pkg4.solution;

public class Triangle extends Shape {
	  // Instance variables
	   private double base;
	   private double height;
	   
	   // Constructor
	   public Triangle(String type,String color, int base, int height) {
	      super(type,color);
	      this.base = base;
	      this.height = height;
	   }
	   
	   public void print() {
		   super.print();
		   System.out.println("Triangle of base=" + base + " and height=" + height);
	   }
	   
	   public void calcArea() {
		   area = 0.5*base*height;
		   System.out.printf("Area is:%.2f%n" ,area);
	   }
}


