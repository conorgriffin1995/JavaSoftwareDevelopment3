package lab.pkg4.solution;

public class Cylinder extends Circle {
	// Instance variables
	private double height;
	private double volume;;

	// Constructor
	public Cylinder(String type,String color, double radius, double height) {
		super(type,color, radius);
		this.height = height;
		this.volume = 0.0;
	}

        @Override
	public void print() {
		super.print();
		System.out.println("Height of cylinder is: " + height);
	}

        @Override
	public void calcArea() {
		area = (2 * Math.PI * radius * radius)
				+ (2 * Math.PI * radius * height);
		System.out.printf("Area is: %.2f%n" ,area);
	}

	public void calcVolume() {

		volume = Math.PI * radius * radius * height;
		System.out.printf("Volume is: %.2f%n" ,volume);
	}
}
