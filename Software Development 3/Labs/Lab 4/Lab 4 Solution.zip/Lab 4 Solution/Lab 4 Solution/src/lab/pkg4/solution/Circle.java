package lab.pkg4.solution;

public class Circle extends Shape {
	// Instance variables
	protected double radius;

	// Constructor
	public Circle(String type,String color, double radius) {
		super(type,color);
		this.radius = radius;
	}

	public void print() {
		super.print();
		System.out.println("Radius is: " + radius);
	}

	public void calcArea() {
		area = Math.PI * radius * radius;
		System.out.printf("Area is: %.2f%n" ,area);
	}

}

