package lab.pkg4.solution;

public class Rectangle extends Shape {
	// Instance variables
	private double length;
	private double width;

        // Overloaded Constructor
	public Rectangle(String type,String color, int length, int width) {
		super(type,color);
		this.length = length;
		this.width = width;
	}

        @Override
	public void print() {
		super.print();
		System.out.println("Rectangle of length=" + length + " and width="
				+ width);
	}

        @Override
	public void calcArea() {

		area = length * width;
		System.out.printf("Area is: %.2f%n" ,area);
	}
}
