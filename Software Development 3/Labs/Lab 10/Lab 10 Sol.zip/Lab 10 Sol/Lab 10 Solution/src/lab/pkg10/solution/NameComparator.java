/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg10.solution;

import java.util.Comparator;

/**
 *
 * @author pmage_000
 */
public class NameComparator implements Comparator<Material> {

    @Override
    public int compare(Material m1, Material m2) {
        String matName1 = m1.getName().toUpperCase();
        String matName2 = m2.getName().toUpperCase();

	//ascending order
        return matName1.compareTo(matName2);
        
        //descending order
        //return matName2.compareTo(matName2);
    }
}


