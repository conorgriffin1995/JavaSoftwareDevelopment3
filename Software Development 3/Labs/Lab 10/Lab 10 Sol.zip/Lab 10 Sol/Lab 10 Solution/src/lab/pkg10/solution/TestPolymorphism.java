package lab.pkg10.solution;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class TestPolymorphism {

    public static void main(String[] args) {
        DecimalFormat f = new DecimalFormat("#,###.##");
        ArrayList<Material> materials = new ArrayList<>();

        // Paint 
        materials.add(new Paint("Dulux Soft Sheen", 11.52, 2, 12));
        materials.add(new Paint("Crown White", 10, 3, 10));
        // Wallpaper �50 per roll, roll length is 10.06, roll width is .52 mtr 
        materials.add(new Wallpaper("Shand Kydd", 50, 10.06, 0.52));
        // Flooring is �65 per pack, coverage of a pack is 1.65sq meters
        materials.add(new Flooring("Quick-Step Planked Oak", 65, 1.65));
        materials.add(new Flooring("Elka Classic Walnut", 80, 1.65));

        Surface aSurface = new Surface("testSurface", 5.7, 5.7);

        for (int i = 0; i < materials.size(); i++) {
            String name = materials.get(i).getName();
            double req = materials.get(i).getMaterialReq(aSurface);
            double price = materials.get(i).calcTotalPrice(aSurface);
            System.out.println("Name: " + name + ", Requirement: "
                    + f.format(req) + " units, Price €" + f.format(price));
            System.out.println();
        }
        
        Collections.sort(materials,new NameComparator());
        
        System.out.println("Sorted Collection");
         for (int i = 0; i < materials.size(); i++) {
            String name = materials.get(i).getName();
            double req = materials.get(i).getMaterialReq(aSurface);
            double price = materials.get(i).calcTotalPrice(aSurface);
            System.out.println("Name: " + name + ", Requirement: "
                    + f.format(req) + " units, Price €" + f.format(price));
            System.out.println();
        }
    }
}
/*
Name: Dulux Soft Sheen, Requirement: 17.33 units, Price €199.62

Name: Crown White, Requirement: 31.19 units, Price €311.9

Name: Shand Kydd, Requirement: 19.87 units, Price €993.73

Name: Quick-Step Planked Oak, Requirement: 19.69 units, Price €1,279.91

Name: Elka Classic Walnut, Requirement: 19.69 units, Price €1,575.27

*/