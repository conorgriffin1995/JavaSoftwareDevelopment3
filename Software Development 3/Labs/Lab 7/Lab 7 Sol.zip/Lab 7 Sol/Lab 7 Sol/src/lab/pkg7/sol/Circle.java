package lab.pkg7.sol;

public class Circle extends TwoDShape
{
 // three-argument constructor
 public Circle( int x, int y, int radius )
 	{
	 	super( x, y, radius, radius );
 	} // end three-argument Circle constructor

 // overridden methods
 public String getName()
 	{
	 	return "Circle";
 	} // end method getName

 public int getArea()
 	{
	 	return (int) (Math.PI * getRadius() * getRadius());
 	} // end method getArea


 // get method
 public int getRadius()
 	{
	 	return getd1();
 	} // end method getRadius

 public String toString()
 	{
	 	return super.toString()+ " radius:" +getRadius();
 	} 
 } 
