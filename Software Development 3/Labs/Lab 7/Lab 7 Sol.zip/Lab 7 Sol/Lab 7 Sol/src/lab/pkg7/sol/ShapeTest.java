package lab.pkg7.sol;

public class ShapeTest
  {
  // create Shape objects and display their information
  public static void main( String args[] )
   {
	  Shape shapes[] = new Shape[ 4 ];
	  shapes[0] = new Circle(22,88,4);
	  shapes[1] = new Square(71,96,10);
	  shapes[2] = new Sphere(8,89,2);
	  shapes[3] = new Cube(79,61,8);

          System.out.println("Number of Shapes created: "+Shape.getNumShapes());
	  // call method print on all shapes
	  for ( int i=0;i<shapes.length;i++)
	  	{
		  System.out.println(shapes[i].getName() + shapes[i]);

		  	if (shapes[i] instanceof TwoDShape )
		  		{
		  			TwoDShape twoDShape =(TwoDShape) shapes[i];
		  			System.out.println( "Area of " +shapes[i].getName()+" is: "+twoDShape.getArea());
		  			System.out.println();
		  		} // end if

		  	if (shapes[i] instanceof ThreeDShape )
		  		{
		  			ThreeDShape threeDShape = ( ThreeDShape ) shapes[i];
		  			System.out.println("Area of "+threeDShape.getName()+" is: "+threeDShape.getArea() );
		  			System.out.printf( "Volume of "+threeDShape.getName()+" is: "+threeDShape.getVolume());
		  			System.out.println();
		  			System.out.println();
		  		} // end if		  	
	  	} // end for
     } // end main
 } // end class ShapeTest
