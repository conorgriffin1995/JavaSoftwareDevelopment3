package lab.pkg7.sol;

public class Sphere extends ThreeDShape
 {
	// three-argument constructor
	public Sphere( int x, int y, int radius )
		{
			super( x, y, radius, radius, radius );
		} // end three-argument Shape constructor

 	// overridden methods
	public String getName()
		{
			return "Sphere";
		} // end method getName

	public int getArea()
		{
			return ( int ) ( 4 * Math.PI * getRadius() * getRadius() );
		} // end method getArea

	public int getVolume()
		{
			return ( int ) ( 4.0 / 3.0 * Math.PI * getRadius()*getRadius()*getRadius() );
		} // end method getVolume

	// get method
	public int getRadius()
		{
			return getLength();
		} // end method getRadius

	public String toString()
		{
			return super.toString()+ " radius:"+ getRadius();
		} // end method toString
 } // end class Sphere
