package lab.pkg7.sol;

public abstract class Shape
 {
	private int x; // x coordinate
	private int y; // y coordinate
        private static int numShapes;

	// two-argument constructor
	public Shape( int x, int y )
	{
		this.x = x;
		this.y = y;
                numShapes++;
	} // end two-argument Shape constructor

        public static int getNumShapes()
        {
            return numShapes;
        }
	// get x coordinate
	public int getX()
	{
		return x;
	} // end method getX

	// get y coordinate
	public int getY()
	{
		return y;
	} // end method getY

	// return String representation of Shape object
	public String toString()
	{
		return "(" +x+ ","+y+")";
	}

	// abstract methods
	public abstract String getName();
 } // end class Shape

