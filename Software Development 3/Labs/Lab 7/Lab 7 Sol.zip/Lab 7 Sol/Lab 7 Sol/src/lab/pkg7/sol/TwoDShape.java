package lab.pkg7.sol;

public abstract class TwoDShape extends Shape
 {
	private int d1;
	private int d2;

	public TwoDShape( int x, int y, int d1, int d2 )
	{
		super( x, y );
		this.d1 = d1;
		this.d2 = d2;
	} 

	// get methods
	public int getd1()
	{
		return d1;
	} // end method getDimension1

	public int getd2()
	{
		return d2;
	} // end method getDimension2

	// abstract method
	public abstract int getArea();
 } 