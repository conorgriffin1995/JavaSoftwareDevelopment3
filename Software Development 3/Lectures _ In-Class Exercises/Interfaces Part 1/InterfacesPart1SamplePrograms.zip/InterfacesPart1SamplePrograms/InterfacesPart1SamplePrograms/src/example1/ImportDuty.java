package example1;

public interface ImportDuty {

	double TAXRATE = 0.10;             
	double calculateDuty();
}




