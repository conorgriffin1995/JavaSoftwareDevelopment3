package example2;

public interface Conversions  extends ConversionFactors{
	double inchToMM(double inches);
	double ounceToGram(double ounces);
	double poundToGram(double pounds);
	double HPToWatt(double hp);
	double wattToHP(double watts);
}

