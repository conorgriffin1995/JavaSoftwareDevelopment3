package inclassexerciseinterfacessolution;
public interface Taxable {
	final double taxRate = 0.06 ;
	double calculateTax() ;
}
