package ex2;

import java.text.NumberFormat;
import java.util.Locale;

public class CurrencyTest {

    public static void main(String[] args) throws Exception {

        double num = 15500.50;

        // Default locale is returned
        NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();
        System.out.println("Euro: " + defaultFormat.format(num));
        // Short Version
        System.out.println("Euro: " + NumberFormat.getCurrencyInstance().format(num));

        // Get the desired locale
        Locale uk = new Locale("en", "GB");
        // Pass desired locale to getCurrencyInstance() method
        NumberFormat ukFormat = NumberFormat.getCurrencyInstance(uk);
        // Call the format() method to format the number according to the desire locale
        System.out.println("Pounds: " + ukFormat.format(num));
        // Short Version
        
        System.out.println("Pounds: " + NumberFormat.getCurrencyInstance(uk).format(num));
        Locale us = new Locale("en", "US");
        NumberFormat usFormat = NumberFormat.getCurrencyInstance(us);
        System.out.println("Dollars: " + usFormat.format(num));
        // Short Version
        System.out.println("Dollars: " + NumberFormat.getCurrencyInstance(us).format(num));
    }
}


