/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

/**
 *
 * @author pmage_000
 */
    public class TestFormat1 {
	public static void main (String args[])
	{	/*
		  double price = 19.8;
		  System.out.print("€");
		  System.out.printf("%5.2f", price);
		  System.out.println(" each");	  

		  String name = "magic apple";
		  System.out.printf("€%5.2f for each %n%s%n", price, name);
		  
		  System.out.printf("The price is €%.2f each.",price);
		  
*/
		  
		  double newPrice = 19.99;
		  System.out.printf("New Price: €%.2f each.",newPrice);
		  
		  String total = String.format("\nNew Price: €%.2f each.",newPrice);
		  System.out.println(total);
		  
	


	}

}
