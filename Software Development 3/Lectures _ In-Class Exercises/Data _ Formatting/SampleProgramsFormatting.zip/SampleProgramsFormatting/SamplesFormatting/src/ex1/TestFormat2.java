/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

/**
 *
 * @author pmage_000
 */
public class TestFormat2 {
    public static void main (String args[])
	{	
		  
	//Floating Point Formatting
        double newPrice = 19.99;                  
        // %f will always give 6 decimal places
        System.out.printf("New Price: €%f each.%n",newPrice);
        // %.2f will always give 2 decimal places
	System.out.printf("New Price: €%.2f each.%n",newPrice);
        // %10.2f will allow 10 chracters for the whole string
        // If there is less than 10 numbers then spaces are used to the left of the numbers
        System.out.printf("New Price: €%10.2f each.%n",newPrice);
        
        // String Formatting
        String name = "magic apples";
        //Format the string with as many characters as is needed
        System.out.printf("%s%n", name);
        //Format the string with the specified number of characters and right justify
        System.out.printf("%15s%n", name);
        //Format the string with the specified number of characters and left justify
        System.out.printf("%-15s%n", name);
        
        //Integer Formatting
        int  number = 72;
        //Format the string with as many numbers as is needed
        System.out.printf("%d%n", number);
        //Format the string with the specified number of integers
        System.out.printf("%4d%n", number);
        //Format the string with the specified number of integers
        // Will pad with zeros to the left if not enough integers
        System.out.printf("%04d%n", number);
        

		  
	


	}
    
}
