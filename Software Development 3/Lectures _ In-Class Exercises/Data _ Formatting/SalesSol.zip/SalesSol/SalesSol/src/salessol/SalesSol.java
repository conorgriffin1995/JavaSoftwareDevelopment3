/*
 * In Class Exercise using Arrays, For Loops and String.format() method
 */
package salessol;

import java.util.Scanner;

public class SalesSol {

    public static void main(String[] args) {
        int[] sales;    // Array declaration
        
        int amount = 0;
        int numOver = 0;
        int numSalesPeople = 0;

        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the number of sales people: ");
        numSalesPeople = scan.nextInt();

        sales = new int[numSalesPeople]; // Array Initialisation

        for (int i = 0; i < sales.length; i++) {
            System.out.print("Enter sales for salesperson " + (i + 1) + ": ");
            sales[i] = scan.nextInt();
        }
        System.out.println("\nSalesperson Sales");
        System.out.println(" ------------------ ");

        int maxSales = Integer.MIN_VALUE;
        int minSales = Integer.MAX_VALUE;
        int maxSalesPerson = 0;
        int minSalesPerson = 0;
        int sum=0;
        for (int i = 0; i < sales.length; i++) {
            sum += sales[i];
            // Note the use of String.format() instead of System.out.printf()
            System.out.println("SalesPerson " + (i + 1) + ": " + String.format("€%,d", sales[i]));

            if (sales[i] > maxSales) {
                maxSales = sales[i];
                maxSalesPerson = i;
            }

            if (sales[i] < minSales) {
                minSales = sales[i];
                minSalesPerson = i;
            }
        }
        System.out.println("\nTotal sales: " + String.format("€%,d", sum));
        System.out.println("\nAverage sales: " + String.format("€%,d", sum / numSalesPeople));
        System.out.println("SalesPerson  " + (maxSalesPerson + 1) + " had the highest sale with: " + String.format("€%,d", maxSales));
        System.out.println("SalesPerson  " + (minSalesPerson + 1) + " had the lowest sale with: " + String.format("€%,d", minSales));

        // Get a target sales value from the user
        System.out.println();
        System.out.print("Enter the target sales amount: ");
        amount = scan.nextInt();

        System.out.println("\nList of sales over " + String.format("€%,d", amount));
        System.out.println();
        System.out.println("Salesperson" + "\t\t" + "Sales");
        for (int i = 0; i < sales.length; i++) {
            if (sales[i] > amount) {
                System.out.println("\t" + (i + 1) + "\t\t" + String.format("€%,d", sales[i]));
                numOver++;
            }
        }

        System.out.println();
        System.out.println(numOver + " sales people had sales over " + String.format("€%,d", amount));

    }
    
}
