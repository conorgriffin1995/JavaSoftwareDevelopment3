/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise1;

import java.io.*;
import java.util.ArrayList;

public class TestEmployee {
    public static void main(String[] args) throws IOException{
    ArrayList<Employee> persons = new ArrayList<>();
    String s, fname, lname;
    int age;
    
     File myDir = new File("files");
        File myFile = new File(myDir, "employees.txt");
        try (BufferedReader in = new BufferedReader(new FileReader(myFile))) {
            while ((s = in.readLine()) != null) {
                fname = s;
                lname = in.readLine();
                age = Integer.parseInt(in.readLine());
                persons.add(new Employee(fname,lname,age));                   
            }
        }   

    for (int i=0;i<persons.size();i++)
    {
        System.out.println(persons.get(i));
    }
    }
    
}
