/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise2;

import java.io.IOException;
import java.util.Scanner;


/**
 *
 * @author pmage_000
 */
public class TestDVDCollection {
    public static void main (String[] args) throws IOException
   {
      Scanner in = new Scanner(System.in);
      DVDCollection films = new DVDCollection();

      films.addDVD();

      System.out.println(films);
   }
   
}
