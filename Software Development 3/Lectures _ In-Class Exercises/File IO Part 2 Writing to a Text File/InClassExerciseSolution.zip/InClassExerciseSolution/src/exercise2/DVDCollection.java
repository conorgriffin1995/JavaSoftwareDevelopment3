/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise2;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Scanner;


/**
 *
 * @author pmage_000
 */
public class DVDCollection {
   private DVD[] collection;
   private int count;
   private double totalCost;


   public DVDCollection ()
   {
      collection = new DVD[4];
      count = 0;
      totalCost = 0.0;
   }

   //-----------------------------------------------------------------
   //  Adds a DVD to the collection
   //-----------------------------------------------------------------
   public void addDVD () throws IOException
   {
       String title, director;
       double price;
       File inFile = new File("files", "collection.txt");
        try (Scanner in = new Scanner(inFile)) {
            while (in.hasNextLine()) {
                title = in.nextLine();    
                director = in.nextLine();
                price = Double.parseDouble(in.nextLine());
                
                collection[count] = new DVD (title, director, price);
                totalCost += price;
                count++;
            }
        }
   }

   //-----------------------------------------------------------------
   //  Returns a report describing the DVD collection.
   //-----------------------------------------------------------------
   @Override
  public String toString()
   {
      NumberFormat fmt = NumberFormat.getCurrencyInstance();

      String report = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      report += "My DVD Collection\n\n";

      report += "Number of DVDs: " + count + "\n";
      report += "Total cost: " + fmt.format(totalCost) + "\n";
      report += "Average cost: " + fmt.format(totalCost/count);

      report += "\n\nDVD List:\n\n";

      for (int cd = 0; cd < count; cd++)
         report += collection[cd].toString() + "\n";

      return report;
   }
}
