package example1;

import java.io.*;

public class FileWriterEx {

    public static void main(String[] args) throws IOException {
        
        int a=1;
        int b=2;
        int c=3;

        File outFile = new File("files", "data.txt");

        try (BufferedWriter bWriter = new BufferedWriter(new FileWriter((outFile)))) {

            bWriter.write(Integer.toString(a));
            bWriter.write(Integer.toString(b));
            bWriter.write(Integer.toString(c));
        }
    }
}

