package exampleSecurity;

public class TestSecurity {
	public static void main(String args[])
 {
    	Security s = new Security();
    	Security.InnerSecurity is = s.new InnerSecurity();
    
    }
}




