package example2MemberInnerClass;

/**
 * Created by Patricia on 19/10/2014.
 */
public class Test {
    public static void main(String[] args) {
        Outer y = new Outer();
        y.setGreeting("Hello, Outer");
        y.displayGreeting();
    }
}
