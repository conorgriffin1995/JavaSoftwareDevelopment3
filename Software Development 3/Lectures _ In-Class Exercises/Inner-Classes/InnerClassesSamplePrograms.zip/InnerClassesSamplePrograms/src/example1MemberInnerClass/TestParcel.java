package example1MemberInnerClass;


public class TestParcel {
	public static void main(String[] args) {
		Parcel p = new Parcel();
		p.ship("Tanzania");
	}
}



