package example4MemberInnerClass;

/**
 * Created by Patricia on 19/10/2014.
 */
public class Test {
    public static void main(String args[]) {
        OuterMember om = new OuterMember();

//        OuterMember.InnerMember i = om.new InnerMember();
//        i.test();
    }
}

