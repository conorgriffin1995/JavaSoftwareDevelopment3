/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exampleAnonymousInnerClass.example2;
import java.util.ArrayList;
import java.util.Collections;

public class TestFruitCollection {
    public static void main(String[] args) {
        ArrayList<Fruit> fruits= new ArrayList<>();
        
        fruits.add(new Fruit("Pineapple", "Pineapple description", 70));
        fruits.add(new Fruit("Apple", "Apple description", 100));
        fruits.add(new Fruit("Orange", "Orange description", 80));
        fruits.add(new Fruit("Banana", "Banana description", 90));
        
        Collections.sort(fruits,Fruit.FruitNameComparator);

        int i = 0;
        for (Fruit temp : fruits) {
            System.out.println("fruits " + ++i + " : " + temp.getFruitName()
                    + ", Quantity : " + temp.getQuantity());
        }
        System.out.println();
        Collections.sort(fruits);

        int j = 0;
        for (Fruit temp : fruits) {
            System.out.println("fruits " + ++j + " : " + temp.getFruitName()
                    + ", Quantity : " + temp.getQuantity());
        }
    }   
}
