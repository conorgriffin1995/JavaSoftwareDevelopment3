package solution;

import java.util.Scanner;

public class TestBand {
	public static void main(String args[]) {

		Scanner in = new Scanner(System.in);

		String names[] = { "John", "Paul", "George", "Ringo" };
		String instruments[] = { "Keyboards", "Guitar", "Guitar", "Drums" };
		RockBand theBeatles = new RockBand("The Beatles", "Apple", names,
				instruments);



        // Implicit call to toString()
		System.out.println(theBeatles);


		System.out.println("Please enter label");
		String newLabel = in.nextLine();
		if (!theBeatles.changeRecordCompany(newLabel))
			System.out.println("Label not changed");
		else {
			System.out.println("Label changed");
			System.out.println(theBeatles);
		}
	}
}


