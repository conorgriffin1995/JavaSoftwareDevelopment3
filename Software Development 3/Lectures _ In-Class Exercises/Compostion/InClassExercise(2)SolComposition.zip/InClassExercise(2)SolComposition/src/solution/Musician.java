package solution;

public class Musician extends Person
{
	public String instrument;
	
	public Musician(String n, String i)
	{
		super(n);
		instrument = i;
	}
	
	public String getInstrument()
	{
		return instrument;
	}
	public void setInstrument(String i)
	{
		instrument = i;
	}


    public String toString()
    {
        return super.toString() + " plays " + instrument +"\n";
    }

}


