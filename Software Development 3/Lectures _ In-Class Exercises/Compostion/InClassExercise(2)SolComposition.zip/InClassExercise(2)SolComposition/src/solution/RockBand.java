package solution;

/** a RockBand */
class RockBand {
	private String bandName; // the name of the band
	private String recordCompany; // the record company for the bad
	private Musician members[]; // the musicians in the band

	/** constructor */
	public RockBand(String bandName, String label, String names[],
			String instruments[]) {
		int bandSize = names.length;

		this.bandName = bandName;
		this.recordCompany = label;
		this.members = new Musician[bandSize]; // create the array

		for (int i = 0; i < bandSize; i++) {
			members[i] = new Musician(names[i], instruments[i]); // new musician
																	// object
		}

	}

	/** change the record company, return false if no change */
	public boolean changeRecordCompany(String newLabel) {
		if (recordCompany.equals(newLabel))
			return false;
		else {
			recordCompany = newLabel;
			return true;
		}
	}

    public String toString()
    {
        String output="";

        output += "Rock Band:" +"\n\tName: " + bandName +"\n\tRecord company: " + recordCompany +"\n";

        for (int i = 0; i < members.length; i++) {
            output +=  members[i];
        }

        return output;
    }

}


