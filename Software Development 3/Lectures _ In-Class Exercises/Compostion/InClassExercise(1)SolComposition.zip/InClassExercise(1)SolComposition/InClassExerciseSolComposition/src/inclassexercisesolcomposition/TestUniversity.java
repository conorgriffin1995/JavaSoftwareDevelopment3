package inclassexercisesolcomposition;

public class TestUniversity {
	public static void main(String[] args){

		int depids[] = {1001,1002,1003,1004};
		String depnames[] = {"Computing", "Business", "Languages", "Engineering"};

		University newUniv=new University("DCU", depids, depnames);	
		newUniv.showList();		
		System.out.println();
		newUniv.changedeptname("Business", "Business & Marketing");
		newUniv.showList();
	}
}



