package example2;

public interface Worker {
	public void work();
}



