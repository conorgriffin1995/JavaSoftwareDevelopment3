package example2;


public class EmpAgency implements Worker {

    public void interview() {
        System.out.println("I interview clients");
    }

    public void work() {
        System.out.println("I am a job agency who tries to find jobs for everyone");
    }

}



