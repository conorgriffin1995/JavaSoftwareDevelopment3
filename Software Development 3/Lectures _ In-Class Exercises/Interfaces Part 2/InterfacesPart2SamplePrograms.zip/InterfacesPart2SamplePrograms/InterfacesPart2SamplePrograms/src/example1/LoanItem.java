package example1;

public interface LoanItem {
	double calculatePrice();
}




