package skeleton;
/**
 * Created by Patricia on 09/10/2014.
 */
public class Invoice {
    private int quantity;
    private double pricePerItem ;
    private String invoiceNumber;
    private String invoiceDescription;

    public Invoice( String part, String description, int count,double price )
    {
        invoiceNumber = part;
        invoiceDescription = description;
        quantity = count;
        pricePerItem = price;
    } // end

    public void setQuantity(int quantity) {

            this.quantity = quantity;

    }

    public void setPricePerItem(double pricePerItem) {

            this.pricePerItem = pricePerItem;

    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public void setInvoiceDescription(String invoiceDescription) {
        this.invoiceDescription = invoiceDescription;
    }

    public int getQuantity() {

        return quantity;
    }

    public double getPricePerItem() {
        return pricePerItem;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public String getInvoiceDescription() {
        return invoiceDescription;
    }


    @Override
    public String toString() {
        return "Invoice" + "\n" +
                "Quantity=" + quantity + "\n" +
                "PricePerItem=" + pricePerItem + "\n" +
                "PartNumber='" + invoiceNumber + '\'' + "\n" +
                "PartDescription='" + invoiceDescription + '\'' +"\n"+
                "Amount Due: €";
    }
}
