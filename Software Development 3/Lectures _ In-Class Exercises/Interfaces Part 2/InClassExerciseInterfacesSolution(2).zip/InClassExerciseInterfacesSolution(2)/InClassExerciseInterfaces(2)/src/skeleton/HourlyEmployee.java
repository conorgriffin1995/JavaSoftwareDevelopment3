package skeleton;

/**
 * Created by Patricia on 09/10/2014.
 */
public class HourlyEmployee extends Employee {
    private double hours;
    private double rate;

    public HourlyEmployee(String fName, String lname, String rsiNumber, double hours, double rate) {
        super(fName, lname, rsiNumber);
        this.hours = hours;
        this.rate = rate;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }



    public double getHours() {
        return hours;
    }

    public void setHours(double hours) {
        this.hours = hours;
    }

    @Override
    public String toString() {
        return super.toString() +getfName() + " " +
                "" +getLname()+" is a salaried employee" + "\n" +
                "WeeklySalary: €";
    }
}
