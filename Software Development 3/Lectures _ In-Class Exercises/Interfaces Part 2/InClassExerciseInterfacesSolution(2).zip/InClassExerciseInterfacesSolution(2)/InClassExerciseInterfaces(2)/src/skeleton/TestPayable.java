package skeleton;

/**
 * Created by Patricia on 09/10/2014.
 */
public class TestPayable {
    public static void main(String args[]) {
//        IPayable[] payableObjects = new IPayable[5];
//
//        // populate array with objects that implementIPayable
//        payableObjects[0]=new Invoice("01234", "Printer", 2, 375.00);
//        payableObjects[1]=new Invoice("56789", "Ink Cartridges", 4, 79.95);
//        payableObjects[2]=new HourlyEmployee("John", "Smith","6578431N", 60,30);
//        payableObjects[3]=new HourlyEmployee("Lisa", "Kelly","9865431M", 20,12);
//        payableObjects[4]=new HourlyEmployee("Mary", "Reilly","9875431M", 20,8);

//        for(int i=0;i<payableObjects.length;i++)
//        {
//            System.out.println(payableObjects[i] +" "+payableObjects[i].getPaymentAmount()+"\n");
//        }

        
    }
}
