package skeleton;

import inclassexerciseinterfaces.pkg2.*;

/**
 * Created by Patricia on 09/10/2014.
 */
public interface IPayable {

    double LOW_TAX_RATE = .23;
    double HIGH_TAX_RATE = .42;
    double VAT_RATE = .235;
    double RANGE_1 = 200;
    double RANGE_2 = 300;

    double getPaymentAmount();

}
