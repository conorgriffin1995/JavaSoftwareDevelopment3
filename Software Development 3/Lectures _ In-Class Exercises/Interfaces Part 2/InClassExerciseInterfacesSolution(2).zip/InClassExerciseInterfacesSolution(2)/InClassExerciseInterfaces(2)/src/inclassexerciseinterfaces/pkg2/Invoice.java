package inclassexerciseinterfaces.pkg2;

/**
 * Created by Patricia on 09/10/2014.
 */
public class Invoice implements IPayable {
    private int quantity;
    private double pricePerItem ;
    private String invoiceNumber;
    private String invoiceDescription;
    
    private static int numInvoices =0;
    private static double vatTotal =0.0;

    public Invoice( String part, String description, int count,double price )
    {
        invoiceNumber = part;
        invoiceDescription = description;
        quantity = count;
        pricePerItem = price;
        numInvoices++;
    } // end

    public static double getVatTotal() {
        return vatTotal;
    }

    public static void setVatTotal(double vatTotal) {
        Invoice.vatTotal = vatTotal;
    }



    public static int getNumInvoices() {
        return numInvoices;
    }

    public static void setNumInvoices(int numInvoices) {
        Invoice.numInvoices = numInvoices;
    }



    public void setQuantity(int quantity) {

            this.quantity = quantity;

    }

    public void setPricePerItem(double pricePerItem) {

            this.pricePerItem = pricePerItem;

    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public void setInvoiceDescription(String invoiceDescription) {
        this.invoiceDescription = invoiceDescription;
    }

    public int getQuantity() {

        return quantity;
    }

    public double getPricePerItem() {
        return pricePerItem;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public String getInvoiceDescription() {
        return invoiceDescription;
    }

    @Override
    public double getPaymentAmount() {
        double vat=0.0;
        double total=0.0;
        double net =0.0;
        net = (pricePerItem*quantity);
        vat = net*VAT_RATE;
        total = vat + net;
        vatTotal= vatTotal+vat;
        return total;
    }

    @Override
    public String toString() {
        return "Invoice" + "\n" +
                "Quantity=" + quantity + "\n" +
                "PricePerItem=" + pricePerItem + "\n" +
                "PartNumber='" + invoiceNumber + '\'' + "\n" +
                "PartDescription='" + invoiceDescription + '\'' +"\n"+
                "Amount Due: €";
    }
}
