/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solution;

import java.util.Scanner;

/**
 *
 * @author pmage_000
 */
public class TestQuestion {
    public static void main(String[] args) {
        
      Question[] quiz = new Question[2];
        
      quiz[0] = new Question("Who was the inventor of the Java language?");
      quiz[0].setAnswer("James Gosling");
      


      ChoiceQuestion c1 = new ChoiceQuestion("In which country was the inventor of Java born?");
      c1.addChoice("Australia", false);
      c1.addChoice("Canada", true);
      c1.addChoice("Denmark", false);
      c1.addChoice("United States", false);
      quiz[1]=c1;
     
      
      
      Scanner in = new Scanner(System.in);
      
      // Enhanced For loop
      for(Question q:quiz)
      {
          q.display();
          System.out.println("Your answer:");
          String response = in.nextLine();
          System.out.println(q.checkAnswer(response));
      }
    }
    
}
