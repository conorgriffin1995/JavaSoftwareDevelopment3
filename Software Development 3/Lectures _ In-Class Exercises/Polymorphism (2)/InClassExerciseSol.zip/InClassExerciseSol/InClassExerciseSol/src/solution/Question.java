/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solution;

/**
 *
 * @author pmage_000
 */
public class Question {
    private String text;
    private String answer;

    public Question() {
        text = "";
        answer = "";
    }
    public Question(String questionText)
    {
        text = questionText;
        answer="";
    }

    public void setAnswer(String correctResponse) {
        answer = correctResponse;
    }

    public boolean checkAnswer(String response) {
        return response.equals(answer);
    }

    public void display() {
        System.out.println(text);
    }
    
}
