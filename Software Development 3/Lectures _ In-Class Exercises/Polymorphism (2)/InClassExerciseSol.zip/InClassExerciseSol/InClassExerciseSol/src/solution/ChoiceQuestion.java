/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solution;

import java.util.ArrayList;

/**
 *
 * @author pmage_000
 */
public class ChoiceQuestion extends Question {
    private ArrayList<String> choices;

    public ChoiceQuestion(String questionText) {
        super(questionText);
        choices=new ArrayList<String>();
    }

    public void addChoice(String choice, boolean correct) {
        choices.add(choice);
       
        if (correct) {
            // Convert choices.size() to string
            //String choiceString = "" + choices.size();
            String choiceString = Integer.toString(choices.size());
            setAnswer(choiceString);
        }
    }

    @Override
    public void display() {
        super.display();
        for(int i=0;i<choices.size();i++)
        {
            int choiceNumber = i+1;
            System.out.println(choiceNumber+ "): "+choices.get(i));
        }
    }
    
}
