/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exampleAnimal2;

/**
 *
 * @author pmage_000
 */
public class TestAnimal {

    public static void main(String args[]) {
        Animal aCollection[] = {new Cat("Brownie", 14), new Dog("Minerva", 6), 
            new Cat("Jack", 2), new Cat("Oscar", 5)};

        for (Animal aCollection1 : aCollection) {
            aCollection1.makeSound();
        }

        Vet X = new Vet("Bobby Newmark");

        for (Animal aCollection1 : aCollection) {
            X.Vaccinate(aCollection1);
        }
    }

}
