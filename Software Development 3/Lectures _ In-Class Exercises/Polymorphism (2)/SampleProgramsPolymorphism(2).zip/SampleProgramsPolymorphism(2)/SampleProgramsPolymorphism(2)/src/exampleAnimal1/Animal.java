/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exampleAnimal1;

/**
 *
 * @author pmage_000
 */
public abstract class Animal {

    private String animalName;
    private int animalAge;

    public Animal() {
        animalName = "";
        animalAge = 0;
    }

    public Animal(String name, int age) {
        animalName = name;
        animalAge = age;
    }

    public abstract void makeSound();

    public String getName() {
        return animalName;
    }

    public int getAge() {
        return animalAge;
    }

}
