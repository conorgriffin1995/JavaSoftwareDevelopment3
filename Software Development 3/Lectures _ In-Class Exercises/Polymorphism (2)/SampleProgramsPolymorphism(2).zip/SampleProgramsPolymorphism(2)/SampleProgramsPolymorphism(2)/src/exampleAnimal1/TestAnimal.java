/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exampleAnimal1;

/**
 *
 * @author pmage_000
 */
public class TestAnimal {

    public static void main(String args[]) {
        Animal animal1, animal2;
        animal1 = new Cat("Brownie", 14);
        animal2 = new Dog("Minerva", 6);
        animal1.makeSound();                  // polymorphic method call
        animal2.makeSound();
    }

}
