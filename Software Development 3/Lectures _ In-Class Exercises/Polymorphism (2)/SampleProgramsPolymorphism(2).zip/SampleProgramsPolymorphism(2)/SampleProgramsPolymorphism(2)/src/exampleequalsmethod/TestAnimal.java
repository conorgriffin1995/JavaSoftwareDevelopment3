/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exampleequalsmethod;

/**
 *
 * @author pmage_000
 */
public class TestAnimal {

    public static void main(String args[]) {
        Animal animal1, animal2;
        animal1 = new Cat("Brownie", 14);
        animal2 = new Cat("Brownie", 14);

        if (animal1.getName().equals(animal2.getName())) {
            System.out.println("Contents are the same");
        }

        Animal a1, a2;
        a1 = new Cat("Julie", 2);
        a2 = a1;

        if (a1 == a2) {
            System.out.println("Object References are the same");
        }

    }
}
