/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inclassexerciseinterfacereference;

/**
 *
 * @author pmage_000
 */
public class Rectangle implements IShape {

    private double width;
    private double length;

    public Rectangle(double w, double l) {
        this.length = l;
        this.width = w;
    }

    @Override
    public double getArea() {
        return this.length * this.width;
    }

    @Override
    public String toString() {
        return "Rectangle(h = " + this.length + ", w = " + this.width + ")";
    }

}
