/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inclassexerciseinterfacereference;

/**
 *
 * @author pmage_000
 */
public class PizzaClient {
    public static void main(String[] args) {
        
    
        Pizza p1 = new Pizza (3.99, new Circle (2.5));
        Pizza p2 =  new Pizza (4.99, new Rectangle (4, 6));
        
        PizzaDeal pd = new PizzaDeal();
        
        System.out.println(p1 + " is a better deal than " + p2 + ": " +
                           pd.betterDeal(p1, p2));
    }  
}
