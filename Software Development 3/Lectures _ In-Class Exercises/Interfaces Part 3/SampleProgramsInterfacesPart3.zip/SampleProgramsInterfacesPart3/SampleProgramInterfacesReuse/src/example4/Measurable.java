package example4;

/**
 * Created by Patricia on 15/10/2014.
 */
public interface Measurable {
    double getMeasure();
}
