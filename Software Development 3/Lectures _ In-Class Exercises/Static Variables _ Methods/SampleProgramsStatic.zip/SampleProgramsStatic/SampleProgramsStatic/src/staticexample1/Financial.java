/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staticexample1;

public class Financial {
    public static double percentOf(double p, double a)
    {
        return (p/100)*a;
    }   
}
