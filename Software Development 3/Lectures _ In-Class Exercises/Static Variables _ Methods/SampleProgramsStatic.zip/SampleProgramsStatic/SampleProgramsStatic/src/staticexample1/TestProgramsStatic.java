/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staticexample1;

public class TestProgramsStatic {
    public static void main(String[] args) {
        
        double taxRate = 42;
        double salary = 25000.0;
        // TODO code application logic here
        double tax = Financial.percentOf(taxRate, salary);
        System.out.println("Tax is: "+tax);      
    } 
}
