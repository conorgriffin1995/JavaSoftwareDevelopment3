package staticblocksexample2;

public class TestStaticBlock {
    public static void main(String[] args){
        StaticBlockExample statEx = new StaticBlockExample();
        StaticBlockExample.staticMethod2();
    }
}
