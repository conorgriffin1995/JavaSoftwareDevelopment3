/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staticfinalexample1;

/**
 *
 * @author pmage_000
 */
public class Student {
    private static final int SCHOOL_ROLLNUMBER = 12345;
    private int stuNum;
    private double gpa;
    
    public Student(int stuNum,double gpa)
    {
        this.stuNum=stuNum;
        this.gpa=gpa;
    }
    
    public void print()
    {
        System.out.println("Student Number: "+stuNum+ " GPA: "+gpa+"\n");
    }
    public static int getNumber()
    {
       return SCHOOL_ROLLNUMBER;
    }
   
}


