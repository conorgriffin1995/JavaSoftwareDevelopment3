/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staticfinalexample1;

public class TestStudent {
     public static void main (String args[])
    {
        Student s1 = new Student(12345,3.5);
        System.out.println("School Roll Number: "+Student.getNumber());
        s1.print();        
 
        Student s2 = new Student(45679,3.0);
        System.out.println("School Roll Number: "+Student.getNumber());
        s2.print();
    }   
}


