package inclassexercisestaticsolution;

public abstract class Employee {

    private String name;
    private static int empCount=0;

    public Employee(String name) {
        this.name = name;
        empCount++;
    }

    public abstract double pay();

    public abstract void sickpay();
    
    public static int getCount()
    {
        return empCount;
    }
    public void resign()
    {
        empCount--;
    }

    @Override
    public String toString() {
        return "Name is " + name;
    }

}
