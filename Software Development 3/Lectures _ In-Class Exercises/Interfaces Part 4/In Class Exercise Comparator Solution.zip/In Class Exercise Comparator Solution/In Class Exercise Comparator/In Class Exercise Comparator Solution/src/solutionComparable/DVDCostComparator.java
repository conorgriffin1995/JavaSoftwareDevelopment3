/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solutionComparable;

import java.util.Comparator;

/**
 *
 * @author pmage_000
 */
public class DVDCostComparator implements Comparator<DVD> {

    @Override
    public int compare(DVD o1, DVD o2) {

        // asc
        return (int) (o1.getCost() - o2.getCost());
    }

}
