/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solutionComparable;

import java.util.Comparator;

/**
 *
 * @author patriciamagee
 */
public class DVDTitleComparator implements Comparator<DVD> {

    @Override
    public int compare(DVD d1, DVD d2) {
        String dvd1 = d1.getName().toUpperCase();
        String dvd2 = d2.getName().toUpperCase();

	//ascending order
        return dvd1.compareTo(dvd2);
    }
    
}


